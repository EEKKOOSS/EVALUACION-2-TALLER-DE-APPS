package cl.inacap;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import cl.inacap.modelo.Manga;
import cl.inacap.modelo.ListaMangas;

public class NuevoMangaActivity extends AppCompatActivity {

    private ListaMangas listaMangas=ListaMangas.getInstancia();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_nuevo_manga);
        Button botonIngresarManga=(Button) findViewById(R.id.botonIngresarManga);
        botonIngresarManga.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ingresarManga(view);
            }
        });
    }

    public void ingresarManga(View view)
    {
        String nombre=((TextView) findViewById(R.id.ingresarNombre)).getText().toString();
        String autor=((TextView) findViewById(R.id.ingresarAutor)).getText().toString();
        String fechaStr=((TextView) findViewById(R.id.ingresarFecha)).getText().toString();
        String demografia=((TextView) findViewById(R.id.ingresarDemografia)).getText().toString();
        String genero=((TextView) findViewById(R.id.ingresarGenero)).getText().toString();

        if(nombre.isEmpty()) {
            Toast.makeText(this, "Ingrese el nombre",Toast.LENGTH_SHORT).show();
        } else if (autor.isEmpty()){
            Toast.makeText(this, "Ingrese el autor",Toast.LENGTH_SHORT).show();
        } else if (fechaStr.isEmpty()) {
            Toast.makeText(this, "Ingrese la fecha", Toast.LENGTH_SHORT).show();
            try {
                int fecha = Integer.parseInt(fechaStr);
                if (fecha <= 0) {
                    Toast.makeText(this, "La cantidad debe ser mayor a cero", Toast.LENGTH_SHORT).show();
            }
                return;


            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }else if (genero.isEmpty())
        {
            Toast.makeText(this, "Ingrese el genero", Toast.LENGTH_SHORT).show();
        } else if (demografia.isEmpty()){
                    Toast.makeText(this, "Ingrese la demografia", Toast.LENGTH_SHORT).show();
        } else {
                    int fecha = Integer.parseInt(fechaStr);
                    Manga manga = new Manga(nombre, autor, fecha, genero, demografia);
                    listaMangas.agregarManga(manga);
                    finish();
                }

    }

}

