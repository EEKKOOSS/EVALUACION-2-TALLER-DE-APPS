package cl.inacap.modelo;

import java.util.ArrayList;

public class ListaMangas {

    private static ListaMangas instancia=new ListaMangas();
    private ArrayList<Manga> listaMangas;

    private ListaMangas() {
        listaMangas=new ArrayList<>();
    }
    public static ListaMangas getInstancia()
    {
        return instancia;
    }

    public void agregarManga(Manga manga)
    {
        listaMangas.add(manga);
    }

    public Manga getManga(int id)
    {
        return listaMangas.get(id);
    }
    public ArrayList<Manga> getListaMangas()
    {
        return listaMangas;
    }

    public void eliminarComprados()
    {
        for(int i=0; i<listaMangas.size();i++)
        {
            if(listaMangas.get(i).isEstado()==Manga.COMPRADO)
            {
                listaMangas.remove(i);
                i--;
            }
        }
    }

}
