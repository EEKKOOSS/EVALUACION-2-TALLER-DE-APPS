package cl.inacap.modelo;

public class Manga {
    //Atributos
    private String nombre;
    private String autor;
    private int fecha;
    private String genero;
    private String demografia;
    private boolean estado;

    //Constantes
    public static final boolean PENDIENTE=true;
    public static final boolean COMPRADO=false;
    //Constructor

    public Manga(String nombre, String autor, int fecha, String genero, String demografia) {
        this.nombre = nombre;
        this.autor = autor;
        this.fecha = fecha;
        this.genero = genero;
        this.demografia = demografia;
        this.estado=PENDIENTE;
    }


    //Métodos accesores y modificadores


    public String getNombre() {
        return nombre;
    }
    public void set(String nombre) {
        this.nombre = nombre;
    }

    public String getAutor() {
        return autor;
    }
    public void setAutor(String autor) {
        this.autor = autor ;
    }

    public String getDemografia() {
        return demografia;
    }
    public void setDemografia(String demografia) {
        this.demografia = demografia;
    }

    public String getGenero() {
        return genero;
    }
    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Integer getFecha() {
        return fecha;
    }
    public void setFecha(Integer fecha) {
        this.fecha = fecha;
    }

    public boolean isEstado() {
        return estado;
    }

    public void setEstado(boolean estado) {
        this.estado = estado;
    }



    @Override
    public String toString() {
        String comprado;
        if(estado==COMPRADO)
        {
            comprado="comprado";
        }
        else
        {
            comprado="pendiente";
        }
        return nombre + ": " + comprado;
    }
}




