package cl.inacap;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

import cl.inacap.modelo.Manga;
import cl.inacap.modelo.ListaMangas;


public class MainActivity extends AppCompatActivity {

    private ListaMangas listaMangas= ListaMangas.getInstancia();
    private ArrayList<Manga> mangas=listaMangas.getListaMangas();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Button ver_lista=(Button) findViewById(R.id.ver_lista);
        ver_lista.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(mangas.size()>0) {
                    Intent intent = new Intent(MainActivity.this, ListaMangasActivity.class);
                    startActivity(intent);
                }
                else
                {
                    Toast.makeText(MainActivity.this, "La lista esta vacia",Toast.LENGTH_SHORT).show();
                }
            }
        });

        Button botonNuevo=(Button) findViewById(R.id.botonNuevo);
        botonNuevo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent=new Intent(MainActivity.this, NuevoMangaActivity.class);
                startActivity(intent);
            }
        });

        Button botonEliminar=(Button) findViewById(R.id.botonEliminar);
        botonEliminar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                listaMangas.eliminarComprados();
                Toast.makeText(MainActivity.this, "Se han eliminado todos los productos comprados", Toast.LENGTH_SHORT).show();
            }
        });
    }
}