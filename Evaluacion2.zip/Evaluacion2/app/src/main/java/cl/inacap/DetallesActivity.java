package cl.inacap;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import cl.inacap.modelo.Manga;
import cl.inacap.modelo.ListaMangas;

public class DetallesActivity extends AppCompatActivity {

    public Manga manga;
    public Intent intent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalles);

        //Obtener el ID desde el intent
        intent=getIntent();
        int id=(Integer) intent.getExtras().get("idManga");

        //Recuperamos el manga desde la lista
        manga= ListaMangas.getInstancia().getManga(id);

        //Mostramos la información del producto
        TextView txtNombre=(TextView) findViewById(R.id.txtNombre);
        txtNombre.setText(manga.getNombre());

        TextView txtAutor=(TextView) findViewById(R.id.txtAutor);
        txtAutor.setText(manga.getAutor());

        TextView txtFecha=(TextView) findViewById(R.id.txtFecha);
        txtFecha.setText("Fecha: "+manga.getFecha());

        TextView txtGenero=(TextView) findViewById(R.id.txtGenero);
        txtGenero.setText(manga.getGenero());

        TextView txtDemografia=(TextView) findViewById(R.id.txtDemografia);
        txtDemografia.setText(manga.getDemografia());

        //Estado, TextView y Botón
        TextView txtEstado=(TextView) findViewById(R.id.txtEstado);
        Button estado=(Button) findViewById(R.id.estado);
        if(manga.isEstado()==Manga.COMPRADO)
        {
            txtEstado.setText("Estado: COMPRADO");
            estado.setText("Marcar como Pendiente");
        }
        else
        {
            txtEstado.setText("Estado: PENDIENTE");
            estado.setText("Marcar como Comprado");
        }
        estado.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                manga.setEstado(!manga.isEstado());
                setResult(RESULT_OK, intent);
                finish();
            }
        });
    }
}
